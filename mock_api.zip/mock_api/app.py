from flask import Flask, request, jsonify, make_response
import uuid
import json
import os

app = Flask(__name__)

# 加载配置文件
config_path = os.path.join(os.path.dirname(__file__), 'config.json')
with open(config_path, 'r', encoding='utf-8') as f:
    config = json.load(f)

sessions = {}


@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    
    if username and password:
        session_id = str(uuid.uuid4())
        sessions[session_id] = {'username': username}
        
        response = make_response(jsonify({
            'code': 200,
            'message': 'ログイン成功'
        }))
        response.headers['X-Session-Id'] = session_id
        return response
    
    return jsonify({'code': 401, 'message': '認証失敗'}), 401


@app.route('/api/logout', methods=['POST'])
def logout():
    data = request.get_json()
    session_id = data.get('sessionId')
    
    if session_id and session_id in sessions:
        del sessions[session_id]
    
    return jsonify({'code': 200, 'message': 'ログアウト成功'})


@app.route('/api/xxx', methods=['GET'])
def get_xxx():
    filter_param = request.args.get('filter')
    items = config['items'].copy()
    
    if filter_param and ':' in filter_param:
        field, value = filter_param.split(':', 1)
        items = [item for item in items if field in item and value.lower() in str(item[field]).lower()]
    
    return jsonify({
        'code': 200,
        'data': items,
        'total': len(items)
    })


@app.route('/api/yyy', methods=['GET'])
def get_yyy():
    filter_param = request.args.get('filter')
    attrs_param = request.args.get('attrs')
    
    items = [item.copy() for item in config['yyy_items']]
    
    if filter_param and ':' in filter_param:
        field, value = filter_param.split(':', 1)
        items = [item for item in items if field in item and value.lower() in str(item[field]).lower()]
    
    if attrs_param:
        attrs = [a.strip() for a in attrs_param.split(',')]
        items = [{k: v for k, v in item.items() if k in attrs or k == 'id'} for item in items]
    
    return jsonify({
        'code': 200,
        'data': items,
        'total': len(items)
    })


@app.route('/api/yyy', methods=['POST'])
def add_yyy():
    action = request.args.get('action')
    
    if action != 'add_yyy':
        return jsonify({'code': 400, 'message': '無効なaction'}), 400
    
    data = request.get_json()
    max_id = max([item['id'] for item in config['yyy_items']], default=0)
    data['id'] = max_id + 1
    config['yyy_items'].append(data)
    
    return jsonify({
        'code': 200,
        'message': '追加成功',
        'data': data
    })


@app.route('/api/yyy/<int:item_id>', methods=['DELETE'])
def delete_yyy(item_id):
    for i, item in enumerate(config['yyy_items']):
        if item['id'] == item_id:
            del config['yyy_items'][i]
            return jsonify({'code': 200, 'message': '削除成功'})
    
    return jsonify({'code': 404, 'message': 'リソースが見つかりません'}), 404


@app.route('/api/zzz', methods=['POST'])
def handle_zzz():
    action = request.args.get('action')
    data = request.get_json() or {}
    
    if action == 'action1':
        # action1: 创建新任务
        max_id = max([item['id'] for item in config['zzz_items']], default=0)
        data['id'] = max_id + 1
        data.setdefault('status', '未着手')
        config['zzz_items'].append(data)
        
        return jsonify({
            'code': 200,
            'message': 'タスク作成成功',
            'data': data
        })
    
    elif action == 'action2':
        # action2: 更新任务状态
        item_id = data.get('id')
        new_status = data.get('status')
        
        for item in config['zzz_items']:
            if item['id'] == item_id:
                item['status'] = new_status
                return jsonify({
                    'code': 200,
                    'message': 'ステータス更新成功',
                    'data': item
                })
        
        return jsonify({'code': 404, 'message': 'タスクが見つかりません'}), 404
    
    elif action == 'action3':
        # action3: 批量删除任务
        ids = data.get('ids', [])
        original_count = len(config['zzz_items'])
        config['zzz_items'][:] = [item for item in config['zzz_items'] if item['id'] not in ids]
        deleted_count = original_count - len(config['zzz_items'])
        
        return jsonify({
            'code': 200,
            'message': f'{deleted_count}件削除成功',
            'deleted_ids': ids
        })
    
    else:
        return jsonify({'code': 400, 'message': '無効なaction'}), 400


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
