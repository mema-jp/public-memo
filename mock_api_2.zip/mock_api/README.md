# Mock API Server

テスト用のモックAPIサーバーです（FastAPI）。

## 環境構築

```bash
pip install -r requirements.txt
```

## 起動方法

```bash
python app.py
```

または

```bash
uvicorn app:app --reload --port 5000
```

サーバーは `http://localhost:5000` で起動します。

API仕様書は `http://localhost:5000/docs` で確認できます。

## API一覧

### 1. ログイン
- **POST** `/api/login`
- Request Body:
```json
{
    "login": {
        "username": "test",
        "password": "123456"
    }
}
```
- Response Header: `X-Session-Id`

### 2. ログアウト
- **POST** `/api/logout`
- Request Body:
```json
{
    "sessionId": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
}
```

### 3. XXX取得
- **GET** `/api/xxx`
- **GET** `/api/xxx?filter=name:田中`
- **GET** `/api/xxx?filter=department:営業部`

### 4. YYY取得
- **GET** `/api/yyy`
- **GET** `/api/yyy?filter=name:プロジェクトA`
- **GET** `/api/yyy?filter=name:プロジェクト&attrs=name,status`

### 5. YYY追加
- **POST** `/api/yyy?action=add_yyy`
- Request Body:
```json
{
    "name": "プロジェクトD",
    "status": "新規",
    "priority": "高",
    "owner": "鈴木"
}
```

### 6. YYY削除
- **DELETE** `/api/yyy/{id}`

### 7. ZZZ操作

#### action1 - タスク作成
- **POST** `/api/zzz?action=action1`
- Request Body:
```json
{
    "name": "タスク4",
    "assignee": "鈴木"
}
```

#### action2 - ステータス更新
- **POST** `/api/zzz?action=action2`
- Request Body:
```json
{
    "id": 1,
    "status": "進行中"
}
```

#### action3 - 一括削除
- **POST** `/api/zzz?action=action3`
- Request Body:
```json
{
    "ids": [1, 2]
}
```
