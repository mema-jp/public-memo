from fastapi import FastAPI, Query, Response, Body
from pydantic import BaseModel
from typing import Optional, List, Any
import uuid
import json
import os

app = FastAPI()

# 加载配置文件
config_path = os.path.join(os.path.dirname(__file__), 'config.json')
with open(config_path, 'r', encoding='utf-8') as f:
    config = json.load(f)


def save_config():
    """保存config到文件"""
    with open(config_path, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=4)


# ========== Models ==========

class LoginInfo(BaseModel):
    username: str
    password: str

class LoginRequest(BaseModel):
    login: LoginInfo

class LogoutRequest(BaseModel):
    sessionId: str

class YyyItem(BaseModel):
    name: str
    status: Optional[str] = None
    priority: Optional[str] = None
    owner: Optional[str] = None


# ========== APIs ==========

@app.post('/api/login')
def login(request: LoginRequest, response: Response):
    username = request.login.username
    password = request.login.password
    
    # 验证用户
    user = next((u for u in config['users'] if u['username'] == username and u['password'] == password), None)
    
    if user:
        session_id = str(uuid.uuid4())
        config['sessions'][session_id] = {'username': username, 'role': user['role']}
        save_config()
        
        response.headers['X-Session-Id'] = session_id
        return {'code': 200, 'message': 'ログイン成功'}
    
    return {'code': 401, 'message': '認証失敗'}


@app.post('/api/logout')
def logout(request: LogoutRequest):
    session_id = request.sessionId
    
    if session_id and session_id in config['sessions']:
        del config['sessions'][session_id]
        save_config()
    
    return {'code': 200, 'message': 'ログアウト成功'}


@app.get('/api/xxx')
def get_xxx(filter: Optional[str] = None):
    items = config['items'].copy()
    
    if filter and ':' in filter:
        field, value = filter.split(':', 1)
        items = [item for item in items if field in item and value.lower() in str(item[field]).lower()]
    
    return {
        'code': 200,
        'data': items,
        'total': len(items)
    }


@app.get('/api/yyy')
def get_yyy(filter: Optional[str] = None, attrs: Optional[str] = None):
    items = [item.copy() for item in config['yyy_items']]
    
    if filter and ':' in filter:
        field, value = filter.split(':', 1)
        items = [item for item in items if field in item and value.lower() in str(item[field]).lower()]
    
    if attrs:
        attr_list = [a.strip() for a in attrs.split(',')]
        items = [{k: v for k, v in item.items() if k in attr_list or k == 'id'} for item in items]
    
    return {
        'code': 200,
        'data': items,
        'total': len(items)
    }


@app.post('/api/yyy')
def add_yyy(item: YyyItem, action: str = Query(...)):
    if action != 'add_yyy':
        return {'code': 400, 'message': '無効なaction'}
    
    data = item.model_dump()
    max_id = max([i['id'] for i in config['yyy_items']], default=0)
    data['id'] = max_id + 1
    config['yyy_items'].append(data)
    save_config()
    
    return {
        'code': 200,
        'message': '追加成功',
        'data': data
    }


@app.delete('/api/yyy/{item_id}')
def delete_yyy(item_id: int):
    for i, item in enumerate(config['yyy_items']):
        if item['id'] == item_id:
            del config['yyy_items'][i]
            save_config()
            return {'code': 200, 'message': '削除成功'}
    
    return {'code': 404, 'message': 'リソースが見つかりません'}


@app.post('/api/zzz')
def handle_zzz(action: str = Query(...), request_body: Any = Body(default=None)):
    data = request_body or {}
    
    if action == 'action1':
        max_id = max([item['id'] for item in config['zzz_items']], default=0)
        data['id'] = max_id + 1
        data.setdefault('status', '未着手')
        config['zzz_items'].append(data)
        save_config()
        
        return {
            'code': 200,
            'message': 'タスク作成成功',
            'data': data
        }
    
    elif action == 'action2':
        item_id = data.get('id')
        new_status = data.get('status')
        
        for item in config['zzz_items']:
            if item['id'] == item_id:
                item['status'] = new_status
                save_config()
                return {
                    'code': 200,
                    'message': 'ステータス更新成功',
                    'data': item
                }
        
        return {'code': 404, 'message': 'タスクが見つかりません'}
    
    elif action == 'action3':
        ids = data.get('ids', [])
        original_count = len(config['zzz_items'])
        config['zzz_items'][:] = [item for item in config['zzz_items'] if item['id'] not in ids]
        deleted_count = original_count - len(config['zzz_items'])
        save_config()
        
        return {
            'code': 200,
            'message': f'{deleted_count}件削除成功',
            'deleted_ids': ids
        }
    
    else:
        return {'code': 400, 'message': '無効なaction'}


if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=5000)
