from fastapi import FastAPI, Query, Response, Body
from pydantic import BaseModel
from typing import Optional, List, Any
import uuid
import json
import os

app = FastAPI()

# ファイルパスの設定
base_path = os.path.dirname(__file__)
master_path = os.path.join(base_path, 'master.json')
data_path = os.path.join(base_path, 'data.json')

# マスタデータの読み込み（読み取り専用）
with open(master_path, 'r', encoding='utf-8') as f:
    master = json.load(f)

# 運用データの読み込み（更新可能）
with open(data_path, 'r', encoding='utf-8') as f:
    data = json.load(f)


def save_data():
    """運用データをファイルに保存"""
    with open(data_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)


# ========== モデル定義 ==========

class LoginInfo(BaseModel):
    username: str
    password: str

class LoginRequest(BaseModel):
    login: LoginInfo

class LogoutRequest(BaseModel):
    sessionId: str

class YyyItem(BaseModel):
    name: str
    status: Optional[str] = None
    priority: Optional[str] = None
    owner: Optional[str] = None


# ========== API定義 ==========

@app.post('/api/login')
def login(request: LoginRequest, response: Response):
    """ログイン処理"""
    username = request.login.username
    password = request.login.password
    
    # マスタデータからユーザーを検証
    user = next((u for u in master['users'] if u['username'] == username and u['password'] == password), None)
    
    if user:
        session_id = str(uuid.uuid4())
        data['sessions'][session_id] = {'username': username, 'role': user['role']}
        save_data()
        
        response.headers['X-Session-Id'] = session_id
        return {'code': 200, 'message': 'ログイン成功'}
    
    return {'code': 401, 'message': '認証失敗'}


@app.post('/api/logout')
def logout(request: LogoutRequest):
    """ログアウト処理"""
    session_id = request.sessionId
    
    if session_id and session_id in data['sessions']:
        del data['sessions'][session_id]
        save_data()
    
    return {'code': 200, 'message': 'ログアウト成功'}


@app.get('/api/xxx')
def get_xxx(filter: Optional[str] = None):
    """XXXデータ取得（マスタデータから読み取り）"""
    items = master['items'].copy()
    
    # フィルター処理（filter=field:value形式）
    if filter and ':' in filter:
        field, value = filter.split(':', 1)
        items = [item for item in items if field in item and value.lower() in str(item[field]).lower()]
    
    return {
        'code': 200,
        'data': items,
        'total': len(items)
    }


@app.get('/api/yyy')
def get_yyy(filter: Optional[str] = None, attrs: Optional[str] = None):
    """YYYデータ取得"""
    items = [item.copy() for item in data['yyy_items']]
    
    # フィルター処理
    if filter and ':' in filter:
        field, value = filter.split(':', 1)
        items = [item for item in items if field in item and value.lower() in str(item[field]).lower()]
    
    # 属性絞り込み（attrs=a,b,c形式）
    if attrs:
        attr_list = [a.strip() for a in attrs.split(',')]
        items = [{k: v for k, v in item.items() if k in attr_list or k == 'id'} for item in items]
    
    return {
        'code': 200,
        'data': items,
        'total': len(items)
    }


@app.post('/api/yyy')
def add_yyy(item: YyyItem, action: str = Query(...)):
    """YYYデータ追加"""
    if action != 'add_yyy':
        return {'code': 400, 'message': '無効なaction'}
    
    item_data = item.model_dump()
    max_id = max([i['id'] for i in data['yyy_items']], default=0)
    item_data['id'] = max_id + 1
    data['yyy_items'].append(item_data)
    save_data()
    
    return {
        'code': 200,
        'message': '追加成功',
        'data': item_data
    }


@app.delete('/api/yyy/{item_id}')
def delete_yyy(item_id: int):
    """YYYデータ削除"""
    for i, item in enumerate(data['yyy_items']):
        if item['id'] == item_id:
            del data['yyy_items'][i]
            save_data()
            return {'code': 200, 'message': '削除成功'}
    
    return {'code': 404, 'message': 'リソースが見つかりません'}


@app.post('/api/zzz')
def handle_zzz(action: str = Query(...), request_body: Any = Body(default=None)):
    """ZZZ操作（action別処理）"""
    body = request_body or {}
    
    if action == 'action1':
        # action1: タスク作成
        max_id = max([item['id'] for item in data['zzz_items']], default=0)
        body['id'] = max_id + 1
        body.setdefault('status', '未着手')
        data['zzz_items'].append(body)
        save_data()
        
        return {
            'code': 200,
            'message': 'タスク作成成功',
            'data': body
        }
    
    elif action == 'action2':
        # action2: ステータス更新
        item_id = body.get('id')
        new_status = body.get('status')
        
        for item in data['zzz_items']:
            if item['id'] == item_id:
                item['status'] = new_status
                save_data()
                return {
                    'code': 200,
                    'message': 'ステータス更新成功',
                    'data': item
                }
        
        return {'code': 404, 'message': 'タスクが見つかりません'}
    
    elif action == 'action3':
        # action3: 一括削除
        ids = body.get('ids', [])
        original_count = len(data['zzz_items'])
        data['zzz_items'][:] = [item for item in data['zzz_items'] if item['id'] not in ids]
        deleted_count = original_count - len(data['zzz_items'])
        save_data()
        
        return {
            'code': 200,
            'message': f'{deleted_count}件削除成功',
            'deleted_ids': ids
        }
    
    else:
        return {'code': 400, 'message': '無効なaction'}


if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=5000)
